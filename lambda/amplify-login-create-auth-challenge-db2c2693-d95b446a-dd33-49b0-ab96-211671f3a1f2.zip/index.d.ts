export function handler(event: any, context: any): Promise<void>;
//# sourceMappingURL=index.d.ts.map